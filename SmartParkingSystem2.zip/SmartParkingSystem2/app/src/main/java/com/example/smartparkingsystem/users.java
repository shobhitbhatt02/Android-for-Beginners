package com.example.smartparkingsystem;

public class users {
    public String fullname,phonenumber,email,gender;
    public users(){

    }
    public users(String fullname, String phonenumber, String email, String gender) {
        this.fullname = fullname;
        this.phonenumber = phonenumber;
        this.email = email;
        this.gender = gender;
    }
}

